#4. Consider the vector x=c(”apple”,”banana”,”grape”)
#Replace the first occurrence of a with ‘$’

x<-c('apple','banana','grape')

sub('a','$',x)