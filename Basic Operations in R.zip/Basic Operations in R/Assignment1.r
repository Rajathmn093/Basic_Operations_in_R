#1. Create a numerical vector to store the odd numbers between 1 to 100

num.vector <- 1:100

odd.vector <- num.vector[num.vector%%2 != 0]
