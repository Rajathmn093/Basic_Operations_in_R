#3. Consider the following vector a<-c(NA,11:15,NA,NA) remove all the NA
#and find the mean of the vector

a<-c(NA,11:15,NA,NA)

mean(a,na.rm = T)