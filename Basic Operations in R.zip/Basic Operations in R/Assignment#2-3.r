#2. Create the numerical vector with following values
#1,2,3,4,5,8,6,2,11
# Create 3x3 matrix from the vector

num.vector <- c(1,2,3,4,5,8,6,2,11)

vector.matrix <- matrix(num.vector,nrow=3)

vector.matrix
